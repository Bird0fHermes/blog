void add_date(char *, FILE *);
int find_line(char *, char *, FILE *);
void print_file(int, char *);
void append_text(char **, int,  FILE *);
void print_help();
